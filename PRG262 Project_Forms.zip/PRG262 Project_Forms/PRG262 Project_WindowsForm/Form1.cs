﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using PRG262_Project_WindowsForm.DBTheStrongestGymDataSetTableAdapters;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace PRG262_Project_WindowsForm
{
    internal class DataHandler
    {
        public DataHandler() { }

        string conn = "Data Source=ANONYMOUS\\SQLEXPRESS; Initial Catalog=DBTheStrongestGym; Integrated Security=SSPI";
        SqlCommand command;
        SqlConnection con;
        SqlDataAdapter adapter;

        public DataTable Read1()
        {
            string query = @"Select * from tblMember";

            SqlDataAdapter da = new SqlDataAdapter(query, conn);

            DataTable dt = new DataTable();

            da.Fill(dt);
            return dt;

        }
        public DataTable Read2()
        {
            string query = @"Select * from tblProgram";

            SqlDataAdapter da = new SqlDataAdapter(query, conn);

            DataTable dt = new DataTable();

            da.Fill(dt);
            return dt;

        }
        public void AddProgram(string pN, string I, string S, string De, int C, int D)
        {
            
            string query = $"INSERT INTO tblProgram(ProgramName, Description, Instructor, Schedule, Capacity, Duration) VALUES ('{pN}','{De}','{I}','{S}',{C},{D})";
            con = new SqlConnection(conn);
            con.Open();
            command = new SqlCommand(query, con);
            try
            {
                command.ExecuteNonQuery();
                MessageBox.Show("New program has been added");
            }
            catch (Exception ex)
            {

                MessageBox.Show("Unable to save new program");
            }
            finally { con.Close(); }

        }
        public void DeleteProgram(int pID)
        {

            string query = $"Delete FROM tblProgram WHERE ProgramID={pID}";
            con = new SqlConnection(conn);
            con.Open();
            command = new SqlCommand(query, con);
            try
            {
                command.ExecuteNonQuery();
                MessageBox.Show("Program has been removed");
            }
            catch (Exception ex)
            {

                MessageBox.Show("Unable to remove program"+ex.Message);
            }
            finally { con.Close(); }

        }
        public void DeleteMember(int pID)
        {

            string query = $"Delete FROM tblMember where MemberID={pID}";
            con = new SqlConnection(conn);
            con.Open();
            command = new SqlCommand(query, con);
            try
            {
                command.ExecuteNonQuery();
                MessageBox.Show("Member has been removed");
            }
            catch (Exception ex)
            {

                MessageBox.Show("Unable to remove Member");
            }
            finally { con.Close(); }

        }
        public void AddMember(string FN, string L, DateTime dob, string G, string pn, string a, int pid, DateTime ms, DateTime me)
        {
            
            

            string query = $"INSERT INTO tblMember(FirstName, LastName, DateofBirth, Gender, PhoneNumber, Address, TrainingProgramID, MembershipStartDate, MembershipEndDate) VALUES ('{FN}', '{L}', '{dob}', '{G}', '{pn}', '{a}', {pid},'{ms}','{me}')";
            con = new SqlConnection(conn);
            con.Open();
            command = new SqlCommand(query, con);
            try
            {
                command.ExecuteNonQuery();
                MessageBox.Show("New program has been added");
            }
            catch (Exception ex)
            {

                MessageBox.Show("Unable to save new program");
            }
            finally { con.Close(); }

        }
        public void UpdateProgram(string c, int i, string ch)
        {
            switch (c)
            {
                case "ProgramName":
                    

                        string query = $"UPDATE tblProgram set [ProgramName] = '{ch}' where ProgramID = {i}";
                        con = new SqlConnection(conn);
                        con.Open();
                        command = new SqlCommand(query, con);
                        try
                        {
                            command.ExecuteNonQuery();
                            MessageBox.Show("Program has been updated");
                        }
                        catch (Exception ex)
                        {

                            MessageBox.Show("Unable to update Program");
                        }
                        finally { con.Close(); }

                   



                    break;
                case "Description":
                   


                        query = $"UPDATE tblProgram set [Description] = '{ch}' where ProgramID = {i}";
                        con = new SqlConnection(conn);
                        con.Open();
                        command = new SqlCommand(query, con);
                        try
                        {
                            command.ExecuteNonQuery();
                            MessageBox.Show("Program has been updated");
                        }
                        catch (Exception ex)
                        {

                            MessageBox.Show("Unable to update Program");
                        }
                        finally { con.Close(); }

                   
                    break;
                case "Instructor":

                    query = $"UPDATE tblProgram set [Instructor] = '{ch}' where ProgramID = {i}";
                    con = new SqlConnection(conn);
                    con.Open();
                    command = new SqlCommand(query, con);
                    try
                    {
                        command.ExecuteNonQuery();
                        MessageBox.Show("Program has been updated");
                    }
                    catch (Exception ex)
                    {

                        MessageBox.Show("Unable to update Program");
                    }
                    finally { con.Close(); }
                    break;
                case "Schedule":
                    query = $"UPDATE tblProgram set [Schedule] = '{ch}' where ProgramID = {i}";
                    con = new SqlConnection(conn);
                    con.Open();
                    command = new SqlCommand(query, con);
                    try
                    {
                        command.ExecuteNonQuery();
                        MessageBox.Show("Program has been updated");
                    }
                    catch (Exception ex)
                    {

                        MessageBox.Show("Unable to update Program");
                    }
                    finally { con.Close(); }
                    break;
                case "Capacity":
                    query = $"UPDATE tblProgram set [Capacity] = {Convert.ToInt32(ch)} where ProgramID = {i}";
                    con = new SqlConnection(conn);
                    con.Open();
                    command = new SqlCommand(query, con);
                    try
                    {
                        command.ExecuteNonQuery();
                        MessageBox.Show("Program has been updated");
                    }
                    catch (Exception ex)
                    {

                        MessageBox.Show("Unable to update Program");
                    }
                    finally { con.Close(); }
                    break;
                case "Duration":
                    try
                    {


                        query = $"UPDATE tblProgram set [Duration] = {Convert.ToInt32(ch)} where ProgramID = {i}";
                        con = new SqlConnection(conn);
                        con.Open();
                        command = new SqlCommand(query, con);
                        try
                        {
                            command.ExecuteNonQuery();
                            MessageBox.Show("Member has been added");
                        }
                        catch (Exception ex)
                        {

                            MessageBox.Show("Unable to update Member");
                        }
                        finally { con.Close(); }

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("An error occurred: " + ex.Message);
                    }

                    break;
                default:
                    MessageBox.Show("Invalid Option");
                    break;
            }
        }
        public void UpdateMember(string c, int i, string ch)
        {
            switch (c)
            {
                case "FirstName":
                    


                    string query = $"UPDATE tblMember set [FirstName] = '{ch}' where MemberID = {i}";
                    con = new SqlConnection(conn);
                    con.Open();
                    command = new SqlCommand(query, con);
                    try
                    {
                        command.ExecuteNonQuery();
                        MessageBox.Show("Member has been updated");
                    }
                    catch (Exception ex)
                    {

                        MessageBox.Show("Unable to update Member");
                    }
                    finally { con.Close(); }


                    break;
                case "LastName":

                    

                    query = $"UPDATE tblMember set [LastName] = '{ch}' where MemberID =  {i}";
                    con = new SqlConnection(conn);
                    con.Open();
                    command = new SqlCommand(query, con);
                    try
                    {
                        command.ExecuteNonQuery();
                        MessageBox.Show("Member has been updated");
                    }
                    catch (Exception ex)
                    {

                        MessageBox.Show("Unable to update Member");
                    }
                    finally { con.Close(); }

                    break;
                case "PhoneNumber":
                  

                    query = $"UPDATE tblMember set [PhoneNumber] = '{ch}' where MemberID = {i}";
                    con = new SqlConnection(conn);
                    con.Open();
                    command = new SqlCommand(query, con);
                    try
                    {
                        command.ExecuteNonQuery();
                        MessageBox.Show("Member has been updated");
                    }
                    catch (Exception ex)
                    {

                        MessageBox.Show("Unable to update Member");
                    }
                    finally { con.Close(); }

                    break;
                case "Address":
                    try
                    {
                       

                        query = $"UPDATE tblMember set [Address] = '{ch}' where MemberID = {i}";
                        con = new SqlConnection(conn);
                        con.Open();
                        command = new SqlCommand(query, con);
                        try
                        {
                            command.ExecuteNonQuery();
                            MessageBox.Show("Member has been updated");
                        }
                        catch (Exception ex)
                        {

                            MessageBox.Show("Unable to update Member");
                        }
                        finally { con.Close(); }

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("An error occurred: " + ex.Message);
                    }

                    break;
                case "TrainingProgramID":
                    try
                    {


                        query = $"UPDATE tblMember set [TrainingProgramID] = {Convert.ToInt32(ch)} where MemberID = {i}";
                        con = new SqlConnection(conn);
                        con.Open();
                        command = new SqlCommand(query, con);
                        try
                        {
                            command.ExecuteNonQuery();
                            MessageBox.Show("Member has been updated");
                        }
                        catch (Exception ex)
                        {

                            MessageBox.Show("Unable to update Member");
                        }
                        finally { con.Close(); }

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("An error occurred: " + ex.Message);
                    }
                    break;
                default:
                    MessageBox.Show("Invalid Option");
                    break;
            }
        }



    }
    
    public partial class Form1 : Form
    {
        public static int error = 3;
        public static bool usernameExists = false;
        public static List<int> ProgramIdentity = new List<int>();   
        
        private DataTable tblProgramTable;
        private DataTable tblMemberTable;
        private SqlDataAdapter tblProgramAdapter;

        private DBTheStrongestGymDataSet DBTheStrongestGymDataSet; // Assuming DBTheStrongestGymDataSet is your dataset name



        public Form1()
        {
            InitializeComponent();
            // Create a DataTable to represent the Customers table
            DataTable tblTempTable = new DataTable();
            tblTempTable.Columns.Add("ProgramID", typeof(int)); // Assuming an auto-incrementing ID
            tblTempTable.Columns.Add("ProgramName", typeof(string));
            tblTempTable.Columns.Add("Instructor", typeof(string));
            tblTempTable.Columns.Add("Schedule", typeof(string));
            tblTempTable.Columns.Add("Capacity", typeof(int));
            tblTempTable.Columns.Add("Duration", typeof(int));

            DBTheStrongestGymDataSet = new DBTheStrongestGymDataSet();
            
        }
        DataHandler handler = new DataHandler();
        

        private void Form1_Load(object sender, EventArgs e)
        {
            button2.Hide();
            panel2.Hide();
            panel4.Hide();
            dataGridView1.Hide();
            dataGridView2.Hide();
            dataGridView3.Hide();
            dataGridView4.Hide();
            button11.Hide();
            panel6.Hide();
            panel7.Hide();
            panel8.Hide();
            panel10.Hide();
            button22.Hide();
            panel11.Hide();
            
            //this.tblProgramTableAdapter1.Fill(this.DBTheStrongestGymDataSet.tblProgram);
            //dataGridView1.DataSource = this.DBTheStrongestGymDataSet.tblProgram;
            
            

            //this.tblprogramTableAdapter.Fill(this.DBTheStrongestGymDataSet.tblProgramTable);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            bool found = false;
            string employeeRecord = textBox1.Text + "," + textBox2.Text;

                string path = "Employees.txt";

            if (error>1)
            {
                if (File.Exists(path))
                {

                    foreach (string line in File.ReadLines(path))
                    {
                        if (line == employeeRecord)
                        {
                            found = true;
                        }


                    }
                    if (found == true)
                    {
                        MessageBox.Show("Welcome back");

                        panel1.Hide();
                        panel2.Show();
                    }
                    else
                    {
                        error = error - 1;
                        MessageBox.Show("User with these credentials does not exist. You have " + error.ToString() + " try(s) left.");
                        textBox1.Text = "";
                        textBox2.Text = "";

                    }

                }
                else
                {
                    MessageBox.Show("File does not exist, it might have been deleted or something");

                }
            }
            else
            {
                MessageBox.Show("System Locked, only the admin can unlock it right now");
               
                textBox1.Hide();
                button1.Hide();
               
                label1.Hide();
                button2.Show();
            }


                

            

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox2.Text=="iamtheadmin")
            {
                MessageBox.Show("The admin has unlocked the system");
                panel2.Show();
            }
            else
            {
                MessageBox.Show("Wrongpasscode");
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (Interaction.InputBox("Enter Password") == "iamtheadmin")
            {
                string filePath = "Employees.txt"; // Update this with the actual file path

               
                string user = Interaction.InputBox("Enter username(it must be atleast 6 characters long)");
                using (StreamReader reader = new StreamReader(filePath))
                {
                    string line;
                   

                    // Read each line until the end of the file
                    while ((line = reader.ReadLine()) != null)
                    {
                        // Split the line by the comma delimiter
                        string[] parts = line.Split(',');

                        // Check if the split result has at least one part (the username)
                        if (parts.Length > 0)
                        {
                            string existingUsername = parts[0].Trim();
                            

                            // Check if the existing username matches the new username
                            if (existingUsername.Equals(user, StringComparison.OrdinalIgnoreCase))
                            {
                                usernameExists = true;
                                break;
                            }
                        }
                    }
                }

                if (user.Length < 6)
                {
                    MessageBox.Show("The username you entered has less than 6 characters");
                }
                else if (usernameExists==true)
                {
                    MessageBox.Show("Please be more original, this username already exists");
                }
                else
                {
                    bool pstry = true;
                    do
                    {
                        string password = Interaction.InputBox("Enter Password(It must be atleast 8 characters long):");
                        if (password.Length < 6)
                        {
                            MessageBox.Show("Password must be atleast 8 characters long");
                        }
                        else
                        {
                            if (password == Interaction.InputBox("Confirm Password"))
                            {
                                pstry = false;
                                string path = "Employees.txt";
                                

                                if (!File.Exists(path))
                                {
                                    // File does not exist, create and write to it
                                    using (StreamWriter writer = new StreamWriter(path))
                                    {
                                        writer.WriteLine(user+","+password);
                                    }

                                    MessageBox.Show("User added successfully");
                                    button2.Hide();
                                    panel2.Hide();
                                }
                                else
                                {
                                    // File exists, append to it
                                    using (StreamWriter writer = new StreamWriter(path, true))
                                    {
                                        writer.WriteLine(user + "," + password);
                                    }

                                    MessageBox.Show("User added successfully");
                                    button2.Hide();
                                    panel2.Hide();
                                }
                            }
                            else
                            {
                                MessageBox.Show("The passwords do not match");
                            }
                        }
                    } while (pstry==true);
                    
                }
            }
            else
            {
                MessageBox.Show("Incorrect Password");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //Program Management Panel
            panel4.Show();
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            //Membership Management Panel
            //panel8.Show();
            panel4.Show();
            panel8.Show();
           
            //panel8.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            // Get the Customers DataTable from your DataSet
            
            dataGridView2.Refresh();
            dataGridView2.Show();
            button11.Show();
            DataTable tblTempTable = new DataTable();
            tblTempTable.Columns.Add("ProgramID", typeof(int)); // Assuming an auto-incrementing ID
            tblTempTable.Columns.Add("ProgramName", typeof(string));
            tblTempTable.Columns.Add("Instructor", typeof(string));
            tblTempTable.Columns.Add("Schedule", typeof(string));
            tblTempTable.Columns.Add("Capacity", typeof(int));
            tblTempTable.Columns.Add("Duration", typeof(int));

            try
            {
               
                foreach (DataRow row in handler.Read2().Rows)
                {
                    tblTempTable.Rows.Add(row["ProgramID"], row["ProgramName"], row["Instructor"], row["Schedule"], row["Capacity"], row["Duration"]);
                    
                }
                dataGridView2.DataSource = tblTempTable;
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }

        }

        private void button7_Click(object sender, EventArgs e)
        {
            //Show Adding Panel
            panel6.Show();
            
        }

        private void button8_Click(object sender, EventArgs e)
        {
            
            //Show Updating Panel
            panel7.Show();
           
            
        }

        private void button9_Click(object sender, EventArgs e)
        {

            //Ask for password then delete
            if (Interaction.InputBox("Enter admin password:") == "iamtheadmin")
            {
                int programID = Convert.ToInt32(Interaction.InputBox("Enter Program ID:"));

                handler.DeleteProgram(programID);
            }
            else
            {
                MessageBox.Show("Incorrect Password");
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            //search input box
            dataGridView2.Refresh();
            dataGridView2.Show();
            button11.Show();
            DataTable tblTempTable = new DataTable();
            tblTempTable.Columns.Add("ProgramID", typeof(int)); // Assuming an auto-incrementing ID
            tblTempTable.Columns.Add("ProgramName", typeof(string));
            tblTempTable.Columns.Add("Instructor", typeof(string));
            tblTempTable.Columns.Add("Schedule", typeof(string));
            tblTempTable.Columns.Add("Capacity", typeof(int));
            tblTempTable.Columns.Add("Duration", typeof(int));
            int programID = Convert.ToInt32(Interaction.InputBox("Enter Program ID:"));
            bool f = false;

            try
            {
               
                dataGridView1.DataSource = handler.Read2();

                // Display all data from the table
                StringBuilder sb = new StringBuilder();
                foreach (DataRow row in handler.Read2().Rows)
                {
                    
                    if (programID == Convert.ToInt32(row["ProgramID"]))
                    {
                        tblTempTable.Rows.Add(row["ProgramID"], row["ProgramName"], row["Instructor"], row["Schedule"], row["Capacity"], row["Duration"]);
                        f= true; break;
                    }
                   

                }
                if (f==true)
                {
                    dataGridView2.DataSource = tblTempTable;
                }
                else
                {
                    MessageBox.Show("Program ID does not exist");
                }
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }

        }

        private void button11_Click(object sender, EventArgs e)
        {
            dataGridView2.Hide();
            button11.Hide();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            string programName = textBox4.Text;
            string description = richTextBox1.Text;
            string instructor = textBox5.Text;
            string schedule = comboBox1.Items[comboBox1.SelectedIndex].ToString();
            int capacity = (int)numericUpDown2.Value;
            int duration = (int)numericUpDown1.Value;


            

            handler.AddProgram(programName, instructor, schedule, description, capacity, duration);
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = handler.Read2();

            panel6.Hide();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void panel7_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button13_Click(object sender, EventArgs e)
        {
            int programID = Convert.ToInt32(Interaction.InputBox("Enter the Program you want to update"));
            string choice = comboBox2.Items[comboBox2.SelectedIndex].ToString();
            string change = textBox3.Text;
            
            panel7.Hide();

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button14_Click(object sender, EventArgs e)
        {
            panel4.Hide();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            panel8.Hide();
            panel4.Hide();

        }

        private void button16_Click(object sender, EventArgs e)
        {
            dataGridView4.Refresh();
            dataGridView4.Show();
            button22.Show();
            DataTable tblTempTable = new DataTable();
            

            tblTempTable.Columns.Add("MemberID", typeof(int));
            tblTempTable.Columns.Add("FirstName", typeof(string));
            tblTempTable.Columns.Add("LastName", typeof(string));
            tblTempTable.Columns.Add("DateOfBirth", typeof(DateTime));
            tblTempTable.Columns.Add("Gender", typeof(string));
            tblTempTable.Columns.Add("PhoneNumber", typeof(string));
            tblTempTable.Columns.Add("Address", typeof(string));
            tblTempTable.Columns.Add("TrainingProgramID", typeof(int)); // Foreign Key
            tblTempTable.Columns.Add("MembershipStartDate", typeof(DateTime));
            tblTempTable.Columns.Add("MembershipEndDate", typeof(DateTime));
            try
            {
               
                foreach (DataRow row in handler.Read1().Rows)
                {
                    tblTempTable.Rows.Add(row["MemberID"], row["FirstName"], row["LastName"], row["DateOfBirth"], row["Gender"], row["PhoneNumber"], row["Address"], row["TrainingProgramID"], row["MembershipStartDate"], row["MembershipEndDate"]);

                }
                dataGridView4.DataSource = tblTempTable;

            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }


        }

        private void button22_Click(object sender, EventArgs e)
        {
            button22.Hide();
            dataGridView4.Hide();
        }

        private void button17_Click(object sender, EventArgs e)
        {
            panel10.Show();
        }

        private void button23_Click(object sender, EventArgs e)
        {
            string FirstName = textBox6.Text;
            string LastName = textBox7.Text;
            DateTime DOB = dateTimePicker1.Value;
            string Gender = comboBox3.Items[comboBox3.SelectedIndex].ToString();
            string phone = textBox8.Text;
            string address = richTextBox2.Text;
            int programID = Convert.ToInt32((textBox9.Text));
            DateTime MStartDate = dateTimePicker2.Value;
            DateTime MEndDate = dateTimePicker3.Value;
            
           handler.AddMember(FirstName,LastName, DOB, Gender, phone, address, programID, MStartDate, MEndDate);


            dataGridView3.DataSource = null;
            dataGridView3.DataSource = handler.Read2();
           
            panel10.Hide();

        }

        private void panel9_Paint(object sender, PaintEventArgs e)
        {

        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button24_Click(object sender, EventArgs e)
        {
            int memberID = Convert.ToInt32(Interaction.InputBox("Enter the Member you want to update"));
            string change = textBox10.Text;
            string choice = comboBox4.Items[comboBox4.SelectedIndex].ToString();
            DataRow[] foundRows = handler.Read1().Select("MemberID = " + memberID);

            if (foundRows.Length > 0)
            {

                handler.UpdateMember(choice, memberID, change);
                
            }
            else
            {
                MessageBox.Show("Member with ID " + memberID.ToString() + " not found.");
            }

            panel11.Hide();

        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button18_Click(object sender, EventArgs e)
        {
            panel11.Show();
        }

        private void button20_Click(object sender, EventArgs e)
        {
            //search input box
            dataGridView4.Refresh();
            dataGridView4.Show();
            button22.Show();
            DataTable tblTempTable = new DataTable();


            tblTempTable.Columns.Add("MemberID", typeof(int));
            tblTempTable.Columns.Add("FirstName", typeof(string));
            tblTempTable.Columns.Add("LastName", typeof(string));
            tblTempTable.Columns.Add("DateOfBirth", typeof(DateTime));
            tblTempTable.Columns.Add("Gender", typeof(string));
            tblTempTable.Columns.Add("PhoneNumber", typeof(string));
            tblTempTable.Columns.Add("Address", typeof(string));
            tblTempTable.Columns.Add("TrainingProgramID", typeof(int)); // Foreign Key
            tblTempTable.Columns.Add("MembershipStartDate", typeof(DateTime));
            tblTempTable.Columns.Add("MembershipEndDate", typeof(DateTime)); ;
            int memberID = Convert.ToInt32(Interaction.InputBox("Enter member ID:"));
            bool f = false;

            try
            {
                
                foreach (DataRow row in handler.Read1().Rows)
                {

                    if (memberID == Convert.ToInt32(row["MemberID"]))
                    {
                        tblTempTable.Rows.Add(row["MemberID"], row["FirstName"], row["LastName"], row["DateOfBirth"], row["Gender"], row["PhoneNumber"], row["Address"], row["TrainingProgramID"], row["MembershipStartDate"], row["MembershipEndDate"]);

                        f = true; break;
                    }


                }
                if (f == true)
                {
                    dataGridView4.DataSource = tblTempTable;
                }
                else
                {
                    MessageBox.Show("Member ID does not exist");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }

        }

        private void button19_Click(object sender, EventArgs e)
        {
            //Ask for password then delete
            if (Interaction.InputBox("Enter admin password:") == "iamtheadmin")
            {
                try
                {
                   
                    
                    int memberID = Convert.ToInt32(Interaction.InputBox("Enter Member ID:"));

                    // Find the row with the specified CustomerID
                    DataRow[] foundRows = handler.Read1().Select("MemberID = " + memberID);

                    if (foundRows.Length > 0)
                    {
                       handler.DeleteMember(memberID);

                        
                    }
                    else
                    {
                        MessageBox.Show("Member with ID " + memberID.ToString() + " not found.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }

            }
            else
            {
                MessageBox.Show("Incorrect Password");
            }

        }

        private void button21_Click(object sender, EventArgs e)
        {
            //search input box
            dataGridView4.Refresh();
            dataGridView4.Show();
            button11.Show();
            DataTable tblTempTable = new DataTable();
            tblTempTable.Columns.Add("ProgramID", typeof(int)); // Assuming an auto-incrementing ID
            tblTempTable.Columns.Add("ProgramName", typeof(string));
            tblTempTable.Columns.Add("Instructor", typeof(string));
            tblTempTable.Columns.Add("Schedule", typeof(string));
            tblTempTable.Columns.Add("Capacity", typeof(int));
            tblTempTable.Columns.Add("Duration", typeof(int));
           string instructor = Interaction.InputBox("Enter Instructor Name:");
            bool f = false;

            try
            {
               
                foreach (DataRow row in handler.Read2().Rows)
                {

                    if (instructor == row["Instructor"].ToString())
                    {
                        tblTempTable.Rows.Add(row["ProgramID"], row["ProgramName"], row["Instructor"], row["Schedule"], row["Capacity"], row["Duration"]);
                        ProgramIdentity.Add(Convert.ToInt32(row["ProgramID"].ToString()));
                        f = true;
                    }


                }
                if (f == true)
                {
                    dataGridView2.DataSource = tblTempTable;
                }
                else
                {
                    MessageBox.Show("Instructor does not exist");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }

            //Transport
            dataGridView4.Refresh();
            dataGridView4.Show();
            button22.Show();
            DataTable tblTempTable1 = new DataTable();


            tblTempTable1.Columns.Add("MemberID", typeof(int));
            tblTempTable1.Columns.Add("FirstName", typeof(string));
            tblTempTable1.Columns.Add("LastName", typeof(string));
            tblTempTable1.Columns.Add("DateOfBirth", typeof(DateTime));
            tblTempTable1.Columns.Add("Gender", typeof(string));
            tblTempTable1.Columns.Add("PhoneNumber", typeof(string));
            tblTempTable1.Columns.Add("Address", typeof(string));
            tblTempTable1.Columns.Add("TrainingProgramID", typeof(int)); // Foreign Key
            tblTempTable1.Columns.Add("MembershipStartDate", typeof(DateTime));
            tblTempTable1.Columns.Add("MembershipEndDate", typeof(DateTime)); ;
            //int memberID = Convert.ToInt32(Interaction.InputBox("Enter member ID:"));
            f = false;
            

            try
            {
                
                foreach (var item in ProgramIdentity)
                {
                    foreach (DataRow row in handler.Read1().Rows)
                    {

                        if (item == Convert.ToInt32(row["TrainingProgramID"]))
                        {
                            tblTempTable1.Rows.Add(row["MemberID"], row["FirstName"], row["LastName"], row["DateOfBirth"], row["Gender"], row["PhoneNumber"], row["Address"], row["TrainingProgramID"], row["MembershipStartDate"], row["MembershipEndDate"]);

                            f = true;
                        }


                    }
                }
                
                if (f == true)
                {
                    dataGridView4.DataSource = tblTempTable1;
                }
                else
                {
                    MessageBox.Show("Member ID does not exist");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }
    }
}
